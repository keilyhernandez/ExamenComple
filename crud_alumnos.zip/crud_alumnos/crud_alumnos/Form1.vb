﻿Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
    Private dv As New DataView
    Dim connect As connect = New connect()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connect.Conectar()
        MostrarDatos()
    End Sub

    Public Sub MostrarDatos()
        connect.Consulta("select * from datos", "datos")
        dgvDatos.DataSource = connect.ds.Tables("datos")
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        BorrarError()
        If (Validar()) Then
            Dim sex As String = ""
            If (rdbM.Checked) Then
                sex = rdbM.Text
            Else
                sex = rdbF.Text
            End If
            Dim agregar As String = "insert into datos values (" + txtCod.Text + ",'" + txtNombre.Text + "','" +
                txtApellido.Text + "','" + txtDireccion.Text + "','" + txtTel.Text + "','" +
                sex + "'," + txtEdad.Text + ")"
            If (connect.Insertar(agregar)) Then
                MessageBox.Show("Los datos fueron agregados correctamente")
                MostrarDatos()
            Else
                MessageBox.Show("Error al agregar")
            End If
        End If
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        If (connect.Eliminar("datos", "id= " + txtCod.Text)) Then
            MessageBox.Show("Datos eliminado correctamente")
            MostrarDatos()
        Else
            MessageBox.Show("Los datos no pudieron ser eliminados")
        End If
    End Sub

    Private Sub dgvDatos_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDatos.CellContentClick
        Dim sex As String = ""
        If (rdbM.Checked) Then
            sex = rdbM.Text
        Else
            sex = rdbF.Text
        End If
        Dim dgv As DataGridViewRow = dgvDatos.Rows(e.RowIndex)
        txtCod.Text = dgv.Cells(0).Value.ToString()
        txtNombre.Text = dgv.Cells(1).Value.ToString()
        txtApellido.Text = dgv.Cells(2).Value.ToString()
        txtDireccion.Text = dgv.Cells(3).Value.ToString()
        txtTel.Text = dgv.Cells(4).Value.ToString()
        sex = dgv.Cells(5).Value.ToString()
        txtEdad.Text = dgv.Cells(6).Value.ToString()
    End Sub

    Private Sub btnActualizar_Click(sender As Object, e As EventArgs) Handles btnActualizar.Click
        BorrarError()
        If (Validar()) Then
            Dim sex As String = ""
            If (rdbM.Checked) Then
                sex = rdbM.Text
            Else
                sex = rdbF.Text
            End If
            Dim actualizar As String = "nombre= '" + txtNombre.Text + "', apellido= '" +
                txtApellido.Text + "', direccion= '" + txtDireccion.Text + "', telefono= '" +
                txtTel.Text + "', sexo= '" + sex + "', edad= " + txtEdad.Text
            If (connect.Actualizar("datos", actualizar, "id= " + txtCod.Text)) Then
                MessageBox.Show("Datos actualizados correctamente")
                MostrarDatos()
            Else
                MessageBox.Show("Los datos no pudieron ser actualizados")
            End If
        End If
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        connect.Limpiar()
        txtCod.Clear()
        txtNombre.Clear()
        txtApellido.Clear()
        txtDireccion.Clear()
        txtTel.Clear()
        txtEdad.Clear()
        txtBuscar.Clear()
    End Sub



    Function Validar()
        Dim ok As Boolean = True
        If (txtCod.Text = "") Then
            ok = False
            ErrorProvider1.SetError(txtCod, "Ingrese un código y que sea mayor que 0")
        End If
        If (txtNombre.Text = "") Then
            ok = False
            ErrorProvider1.SetError(txtNombre, "Ingrese un nombre")
        End If
        If (txtApellido.Text = "") Then
            ok = False
            ErrorProvider1.SetError(txtApellido, "Ingrese un apellido")
        End If
        If (txtDireccion.Text = "") Then
            ok = False
            ErrorProvider1.SetError(txtDireccion, "Ingrese una dirección")
        End If
        If (txtTel.Text = "") Then
            ok = False
            ErrorProvider1.SetError(txtTel, "Ingrese un télefono")
        End If
        If (txtEdad.Text = "") Then
            ok = False
            ErrorProvider1.SetError(txtEdad, "Ingrese una edad y que sea mayor a 0")
        End If
        Return ok
    End Function
    Private Sub BorrarError()
        ErrorProvider1.SetError(txtCod, "")
        ErrorProvider1.SetError(txtNombre, "")
        ErrorProvider1.SetError(txtApellido, "")
        ErrorProvider1.SetError(txtDireccion, "")
        ErrorProvider1.SetError(txtTel, "")
        ErrorProvider1.SetError(txtEdad, "")
    End Sub


    Sub SoloNumeros(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo número", MsgBoxStyle.Exclamation, "Ingreso de Número")
        End If
    End Sub
    Sub SoloLetras(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo texto", MsgBoxStyle.Exclamation, "Ingreso de Texto")
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = False
        End If
    End Sub

    Private Sub txtCod_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCod.KeyPress
        SoloNumeros(e)
    End Sub

    Private Sub txtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNombre.KeyPress
        SoloLetras(e)
    End Sub

    Private Sub txtApellido_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtApellido.KeyPress
        SoloLetras(e)
    End Sub

    Private Sub txtEdad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEdad.KeyPress
        SoloNumeros(e)
    End Sub

    Private Sub txtBuscar_TextChanged(sender As Object, e As EventArgs) Handles txtBuscar.TextChanged
        dv.RowFilter = String.Format("nombre like '{0}%'", txtBuscar.Text)
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Dim cnn As New SqlConnection("Data Source=localhost;Initial Catalog=alumnos;Integrated Security=True")
        Dim da As New SqlDataAdapter("select *from datos", cnn)
        Dim ds As New DataSet()
        da.Fill(ds)
        dv.Table = ds.Tables(0)
        dgvDatos.DataSource = dv
    End Sub
End Class
